package com.example.computer.yogaapp;

/**
 * Created by Travis on 3/5/2016.
 */
public class User {

    String username, password;

    public User (String username, String password){
        this.username = username;
        this.password = password;
    }

}
