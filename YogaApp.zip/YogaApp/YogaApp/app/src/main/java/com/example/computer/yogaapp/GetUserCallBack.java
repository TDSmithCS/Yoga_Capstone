package com.example.computer.yogaapp;

/**
 * Created by Travis on 3/5/2016.
 */
interface GetUserCallBack {
    public abstract void done(User returnedUser);
}
